package mx.petcalli.petcalli_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetcalliBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetcalliBackendApplication.class, args);
	}

}
